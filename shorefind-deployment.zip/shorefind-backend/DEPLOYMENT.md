# ShoreFind — Deployment Guide

## Project structure

```
shorefind-backend/
├── src/
│   ├── server.js               # Express entry point
│   ├── db.js                   # PostgreSQL pool
│   ├── email.js                # Resend email (welcome template)
│   ├── middleware/
│   │   └── auth.js             # JWT middleware
│   └── routes/
│       ├── auth.js             # signup / login / profile / delete
│       ├── logbook.js          # log a find / fetch collection
│       ├── leaderboard.js      # public ranked list
│       └── images.js           # shell photo upload + resize
├── migrations/
│   ├── run.js                  # migration runner
│   ├── 001_initial_schema.sql  # users, logbook_entries, monthly_points
│   └── 002_seed_community.sql  # 6 sample beachcombers
├── public/
│   └── shorefind.html          # → rename to index.html and copy here
├── .env.example
└── package.json
```

---

## 1. Quick local setup

```bash
# 1. Clone / unzip, then:
cd shorefind-backend
npm install

# 2. Copy env file and fill in your values
cp .env.example .env
# edit DATABASE_URL, JWT_SECRET, RESEND_API_KEY, EMAIL_FROM

# 3. Create the local database (requires psql)
createdb shorefind

# 4. Run migrations + seed
npm run migrate

# 5. Copy the frontend into public/
cp /path/to/shorefind.html public/index.html

# 6. Start the dev server
npm run dev
# → http://localhost:3000
```

> **Meta tag** — if you're running the frontend from a different origin
> than the API, add this to `shorefind.html`'s `<head>`:
> ```html
> <meta name="api-base" content="https://api.yourdomain.com">
> ```
> If the HTML is served from the same Express server (recommended),
> you don't need the tag at all.

---

## 2. Deploy to Render (recommended — free tier available)

### 2a. Database — Render PostgreSQL
1. **Render dashboard → New → PostgreSQL**
2. Name it `shorefind-db`, choose the free plan
3. Copy the **External Database URL** for local use;  
   the **Internal Database URL** for the web service

### 2b. Web service
1. **New → Web Service** → connect your GitHub repo (or use "Deploy from existing image")
2. Settings:
   | Field | Value |
   |-------|-------|
   | **Root directory** | `shorefind-backend` |
   | **Build command** | `npm install` |
   | **Start command** | `node src/server.js` |
   | **Node version** | 20 |
3. **Environment variables** (add all from `.env.example`):
   - `DATABASE_URL` → Internal Database URL from step 2a
   - `JWT_SECRET` → a 64-char random hex string
   - `RESEND_API_KEY` → from resend.com
   - `EMAIL_FROM` → `ShoreFind <hello@yourdomain.com>`
   - `FRONTEND_URL` → your Render web service URL  
     e.g. `https://shorefind.onrender.com`
   - `NODE_ENV` → `production`

4. **Deploy** — Render will run `npm install` then `node src/server.js`

5. **Run migrations** — in the Render shell tab:
   ```bash
   node migrations/run.js
   ```

6. **Copy the frontend** — add `shorefind.html` to your repo as  
   `shorefind-backend/public/index.html` and redeploy.

---

## 3. Deploy to Railway

```bash
# Install Railway CLI
npm install -g @railway/cli
railway login

# From shorefind-backend/
railway init
railway add --database postgresql   # provisions Postgres, sets DATABASE_URL
railway variables set JWT_SECRET=... RESEND_API_KEY=... EMAIL_FROM=... NODE_ENV=production
railway up
railway run node migrations/run.js
```

---

## 4. Email — Resend setup

1. Sign up at **https://resend.com** (free tier: 3 000 emails/mo)
2. **Domains → Add domain** — verify your domain via DNS TXT record  
   (takes 1–5 min)
3. **API Keys → Create** — copy the key into `RESEND_API_KEY`
4. Set `EMAIL_FROM` to `ShoreFind <hello@yourdomain.com>`

**No domain yet?** You can send from `onboarding@resend.dev` on the
free tier for testing — just set `EMAIL_FROM=ShoreFind <onboarding@resend.dev>`.

If `RESEND_API_KEY` is not set (local dev), the welcome email is printed
to the console instead of sent.

---

## 5. Production image storage (S3 / Cloudflare R2)

The default saves uploaded shell photos to `public/uploads/` on the
server's disk — fine for local dev, but **ephemeral on Render/Railway**.

To switch to cloud storage, edit `src/routes/images.js` — only the
`router.post('/upload', ...)` handler body needs to change:

```js
// Example: Cloudflare R2 via the S3-compatible SDK
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const s3 = new S3Client({
  region: 'auto',
  endpoint: process.env.R2_ENDPOINT,       // https://<accountid>.r2.cloudflarestorage.com
  credentials: {
    accessKeyId:     process.env.R2_ACCESS_KEY,
    secretAccessKey: process.env.R2_SECRET_KEY,
  },
});

const resized = await sharp(req.file.buffer)
  .resize(640, 640, { fit: 'inside', withoutEnlargement: true })
  .jpeg({ quality: 78 })
  .toBuffer();

const filename = `${uuidv4()}.jpg`;
await s3.send(new PutObjectCommand({
  Bucket: process.env.R2_BUCKET,
  Key: `uploads/${filename}`,
  Body: resized,
  ContentType: 'image/jpeg',
}));

const url = `${process.env.R2_PUBLIC_URL}/uploads/${filename}`;
return res.json({ url });
```

Add `@aws-sdk/client-s3` to `package.json` dependencies and set the
four `R2_*` env vars (or swap for S3 equivalents).

---

## 6. Environment variable reference

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `JWT_SECRET` | ✅ | Random 48+ char string for signing tokens |
| `JWT_EXPIRES_IN` | — | Default `30d` |
| `RESEND_API_KEY` | ✅ prod | From resend.com — console fallback if absent |
| `EMAIL_FROM` | ✅ prod | `Name <email@domain.com>` |
| `FRONTEND_URL` | ✅ prod | Used in email CTA links |
| `PORT` | — | Default `3000` |
| `NODE_ENV` | — | `production` enables SSL for DB |
| `UPLOAD_DIR` | — | Override local upload path |

---

## 7. API reference

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/auth/signup` | — | Register; returns `{ token, user }` |
| `POST` | `/auth/login` | — | Login; returns `{ token, user }` |
| `GET` | `/auth/me` | JWT | Current user profile |
| `PATCH` | `/auth/profile` | JWT | Update name / beach |
| `POST` | `/auth/change-password` | JWT | Verify old pw, set new |
| `DELETE` | `/auth/account` | JWT | Permanently delete account |
| `POST` | `/logbook` | JWT | Log a shell find |
| `GET` | `/logbook` | JWT | Fetch user's collection |
| `POST` | `/images/upload` | JWT | Upload + resize shell photo |
| `GET` | `/leaderboard` | optional JWT | Ranked list (`filter=alltime\|month\|local`) |
| `GET` | `/health` | — | Uptime check |

JWT goes in `Authorization: Bearer <token>` on every protected request.
