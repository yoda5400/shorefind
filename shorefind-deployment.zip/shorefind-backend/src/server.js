/**
 * src/server.js
 * ShoreFind — main Express application entry point.
 *
 * Endpoints:
 *   POST   /auth/signup
 *   POST   /auth/login
 *   GET    /auth/me
 *   PATCH  /auth/profile
 *   POST   /auth/change-password
 *   DELETE /auth/account
 *
 *   POST   /logbook           (auth)
 *   GET    /logbook           (auth)
 *
 *   POST   /images/upload     (auth)
 *
 *   GET    /leaderboard       (public, optional auth for isActive flag)
 *
 *   GET    /health            (public — uptime check)
 */
require('dotenv').config();

const express     = require('express');
const helmet      = require('helmet');
const cors        = require('cors');
const rateLimit   = require('express-rate-limit');
const path        = require('path');

const authRouter        = require('./routes/auth');
const logbookRouter     = require('./routes/logbook');
const leaderboardRouter = require('./routes/leaderboard');
const imagesRouter      = require('./routes/images');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Security headers ───────────────────────────────────────
app.use(helmet({
  // Allow the app to be embedded in the claude.ai artifact preview
  contentSecurityPolicy: false,
}));

// ── CORS ───────────────────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5173',   // Vite dev server if you split front/back
].filter(Boolean);

app.use(cors({
  origin(origin, cb) {
    // Allow requests with no origin (mobile apps, Postman, curl)
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
}));

// ── Body parsing ───────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));

// ── Rate limiting ──────────────────────────────────────────
// Tight limit on auth endpoints to resist brute-force
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests — please wait and try again.' },
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests — please slow down.' },
});

// ── Static files (uploaded shell images) ──────────────────
// In production serve these from a CDN / cloud storage instead.
app.use('/uploads', express.static(path.join(__dirname, '../public/uploads')));

// Serve the frontend HTML at the root if it lives in /public
app.use(express.static(path.join(__dirname, '../public')));

// ── Routes ─────────────────────────────────────────────────
app.use('/auth',        authLimiter, authRouter);
app.use('/logbook',     apiLimiter,  logbookRouter);
app.use('/leaderboard', apiLimiter,  leaderboardRouter);
app.use('/images',      apiLimiter,  imagesRouter);

// ── Health check ───────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ ok: true, env: process.env.NODE_ENV, ts: new Date().toISOString() });
});

// ── 404 fallback ───────────────────────────────────────────
// Return the SPA for any unmatched GET so client-side routing works.
app.get('*', (req, res) => {
  const indexPath = path.join(__dirname, '../public/index.html');
  res.sendFile(indexPath, err => {
    if (err) res.status(404).json({ error: 'Not found.' });
  });
});

// ── Global error handler ───────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[server error]', err.message);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── Start ──────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\nShoreFind backend running on http://localhost:${PORT}`);
  console.log(`  NODE_ENV  : ${process.env.NODE_ENV || 'development'}`);
  console.log(`  DATABASE  : ${process.env.DATABASE_URL ? '✔ configured' : '✖ DATABASE_URL not set'}`);
  console.log(`  EMAIL     : ${process.env.RESEND_API_KEY && !process.env.RESEND_API_KEY.startsWith('re_xxx') ? '✔ Resend configured' : '  console-only (set RESEND_API_KEY)'}`);
  console.log(`  JWT       : ${process.env.JWT_SECRET && process.env.JWT_SECRET !== 'change_me_to_a_long_random_string' ? '✔ secret set' : '✖ JWT_SECRET not set'}\n`);
});

module.exports = app;
