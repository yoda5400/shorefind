/**
 * src/routes/auth.js
 * Authentication endpoints.
 *
 * POST   /auth/signup           — register, receive JWT
 * POST   /auth/login            — login, receive JWT
 * GET    /auth/me               — return the authed user's profile
 * PATCH  /auth/profile          — update name + beach
 * POST   /auth/change-password  — verify old pw, set new pw
 * DELETE /auth/account          — permanently delete account
 */
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { z }   = require('zod');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { sendWelcomeEmail } = require('../email');

// ── helpers ────────────────────────────────────────────────
function sign(user) {
  return jwt.sign(
    { id: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
  );
}

function toPublic(row) {
  return {
    id:          row.id,
    email:       row.email,
    name:        row.name,
    initials:    row.initials,
    beach:       row.beach,
    points:      row.points,
    shellsFound: row.shells_found,
    rareFinds:   row.rare_finds,
    createdAt:   row.created_at,
  };
}

function makeInitials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '?';
}

// ── POST /auth/signup ──────────────────────────────────────
const SignupSchema = z.object({
  name:     z.string().trim().min(1, 'Name is required.').max(80),
  email:    z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
  beach:    z.string().trim().max(120).optional(),
});

router.post('/signup', async (req, res) => {
  const parsed = SignupSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }
  const { name, email, password, beach } = parsed.data;

  try {
    const exists = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (exists.rows.length) {
      return res.status(409).json({ error: 'An account with that email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const initials     = makeInitials(name);

    const { rows } = await query(
      `INSERT INTO users (email, name, initials, beach, password_hash)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [email.toLowerCase(), name, initials, beach || 'Cape Elara Shoreline', passwordHash]
    );
    const user = rows[0];

    // Fire-and-forget — don't await so signup is instant
    sendWelcomeEmail(user);

    return res.status(201).json({ token: sign(user), user: toPublic(user) });
  } catch (err) {
    console.error('[auth/signup]', err.message);
    return res.status(500).json({ error: 'Server error during signup.' });
  }
});

// ── POST /auth/login ───────────────────────────────────────
const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(1),
});

router.post('/login', async (req, res) => {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid email or password.' });
  }
  const { email, password } = parsed.data;

  try {
    const { rows } = await query('SELECT * FROM users WHERE email = $1', [email.toLowerCase()]);
    if (!rows.length) {
      return res.status(401).json({ error: "We couldn't find an account for that email." });
    }
    const user  = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Incorrect password.' });
    }
    return res.json({ token: sign(user), user: toPublic(user) });
  } catch (err) {
    console.error('[auth/login]', err.message);
    return res.status(500).json({ error: 'Server error during login.' });
  }
});

// ── GET /auth/me ───────────────────────────────────────────
router.get('/me', requireAuth, async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'User not found.' });
    return res.json({ user: toPublic(rows[0]) });
  } catch (err) {
    console.error('[auth/me]', err.message);
    return res.status(500).json({ error: 'Server error.' });
  }
});

// ── PATCH /auth/profile ────────────────────────────────────
const ProfileSchema = z.object({
  name:  z.string().trim().min(1).max(80).optional(),
  beach: z.string().trim().min(1).max(120).optional(),
});

router.patch('/profile', requireAuth, async (req, res) => {
  const parsed = ProfileSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }
  const updates = parsed.data;
  if (!Object.keys(updates).length) {
    return res.status(400).json({ error: 'Nothing to update.' });
  }

  try {
    const setClauses = [];
    const values     = [];
    let   i          = 1;
    if (updates.name) {
      setClauses.push(`name = $${i++}`, `initials = $${i++}`);
      values.push(updates.name, makeInitials(updates.name));
    }
    if (updates.beach) {
      setClauses.push(`beach = $${i++}`);
      values.push(updates.beach);
    }
    values.push(req.user.id);
    const { rows } = await query(
      `UPDATE users SET ${setClauses.join(', ')} WHERE id = $${i} RETURNING *`,
      values
    );
    return res.json({ user: toPublic(rows[0]) });
  } catch (err) {
    console.error('[auth/profile]', err.message);
    return res.status(500).json({ error: 'Server error.' });
  }
});

// ── POST /auth/change-password ─────────────────────────────
const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword:     z.string().min(6, 'New password must be at least 6 characters.'),
});

router.post('/change-password', requireAuth, async (req, res) => {
  const parsed = ChangePasswordSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }
  const { currentPassword, newPassword } = parsed.data;

  try {
    const { rows } = await query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'User not found.' });

    const match = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!match) return res.status(401).json({ error: 'Incorrect current password.' });

    const newHash = await bcrypt.hash(newPassword, 10);
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, req.user.id]);
    return res.json({ ok: true });
  } catch (err) {
    console.error('[auth/change-password]', err.message);
    return res.status(500).json({ error: 'Server error.' });
  }
});

// ── DELETE /auth/account ───────────────────────────────────
router.delete('/account', requireAuth, async (req, res) => {
  try {
    // ON DELETE CASCADE handles logbook_entries and monthly_points
    await query('DELETE FROM users WHERE id = $1', [req.user.id]);
    return res.json({ ok: true });
  } catch (err) {
    console.error('[auth/account DELETE]', err.message);
    return res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
