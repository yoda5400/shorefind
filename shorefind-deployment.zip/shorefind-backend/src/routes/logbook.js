/**
 * src/routes/logbook.js
 *
 * POST  /logbook      — log a shell find, award points
 * GET   /logbook      — return the authed user's logbook (paginated)
 */
const router  = require('express').Router();
const { z }   = require('zod');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

const RARITY_POINTS = { common: 10, uncommon: 25, rare: 50, ultra: 100 };

// ── POST /logbook ──────────────────────────────────────────
const LogSchema = z.object({
  shellId:    z.string().max(80),
  shellName:  z.string().max(120),
  sciName:    z.string().max(160),
  rarity:     z.enum(['common', 'uncommon', 'rare', 'ultra']),
  confidence: z.number().int().min(0).max(100),
  imageUrl:   z.string().url().optional().nullable(),
  fact:       z.string().max(600).optional().nullable(),
});

router.post('/', requireAuth, async (req, res) => {
  const parsed = LogSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }
  const { shellId, shellName, sciName, rarity, confidence, imageUrl, fact } = parsed.data;
  const pts    = RARITY_POINTS[rarity];
  const isRare = rarity === 'rare' || rarity === 'ultra';
  const userId = req.user.id;

  try {
    // Insert logbook entry
    const { rows: [entry] } = await query(
      `INSERT INTO logbook_entries
         (user_id, shell_id, shell_name, sci_name, rarity, points, confidence, image_url, fact)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [userId, shellId, shellName, sciName, rarity, pts, confidence, imageUrl ?? null, fact ?? null]
    );

    // Update user totals atomically
    const { rows: [user] } = await query(
      `UPDATE users
         SET points       = points + $1,
             shells_found = shells_found + 1,
             rare_finds   = rare_finds + $2
       WHERE id = $3
       RETURNING points, shells_found, rare_finds`,
      [pts, isRare ? 1 : 0, userId]
    );

    // Upsert monthly_points for "This Month" leaderboard
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    await query(
      `INSERT INTO monthly_points (user_id, month, points, shells, rare_finds)
       VALUES ($1, $2, $3, 1, $4)
       ON CONFLICT (user_id, month) DO UPDATE
         SET points     = monthly_points.points + EXCLUDED.points,
             shells     = monthly_points.shells + 1,
             rare_finds = monthly_points.rare_finds + EXCLUDED.rare_finds`,
      [userId, monthStart.toISOString().slice(0, 10), pts, isRare ? 1 : 0]
    );

    return res.status(201).json({
      entry: {
        id:         entry.id,
        shellName:  entry.shell_name,
        sciName:    entry.sci_name,
        rarity:     entry.rarity,
        points:     entry.points,
        confidence: entry.confidence,
        imageUrl:   entry.image_url,
        fact:       entry.fact,
        foundAt:    entry.found_at,
      },
      userStats: {
        points:      user.points,
        shellsFound: user.shells_found,
        rareFinds:   user.rare_finds,
      },
    });
  } catch (err) {
    console.error('[logbook POST]', err.message);
    return res.status(500).json({ error: 'Server error logging shell.' });
  }
});

// ── GET /logbook ───────────────────────────────────────────
router.get('/', requireAuth, async (req, res) => {
  const limit  = Math.min(Number(req.query.limit)  || 50, 100);
  const offset = Math.max(Number(req.query.offset) || 0,  0);

  try {
    const { rows } = await query(
      `SELECT id, shell_name, sci_name, rarity, points, confidence, image_url, fact, found_at
         FROM logbook_entries
        WHERE user_id = $1
        ORDER BY found_at DESC
        LIMIT $2 OFFSET $3`,
      [req.user.id, limit, offset]
    );
    return res.json({
      entries: rows.map(r => ({
        id:         r.id,
        shellName:  r.shell_name,
        sciName:    r.sci_name,
        rarity:     r.rarity,
        points:     r.points,
        confidence: r.confidence,
        imageUrl:   r.image_url,
        fact:       r.fact,
        foundAt:    r.found_at,
      })),
    });
  } catch (err) {
    console.error('[logbook GET]', err.message);
    return res.status(500).json({ error: 'Server error fetching logbook.' });
  }
});

module.exports = router;
