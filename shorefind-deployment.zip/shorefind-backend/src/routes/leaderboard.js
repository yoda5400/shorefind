/**
 * src/routes/leaderboard.js
 *
 * GET /leaderboard?filter=alltime|month|local&beach=<name>&limit=50
 *
 * Returns ranked rows. No auth required — the leaderboard is public.
 * The authed user's own row is flagged with isActive:true when a
 * valid Bearer token is supplied (optional on this route).
 */
const router = require('express').Router();
const jwt    = require('jsonwebtoken');
const { query } = require('../db');

function optionalAuth(req) {
  try {
    const h = req.headers.authorization;
    if (h && h.startsWith('Bearer ')) {
      return jwt.verify(h.slice(7), process.env.JWT_SECRET);
    }
  } catch (_) { /* expired / invalid — treat as unauthenticated */ }
  return null;
}

router.get('/', async (req, res) => {
  const filter = req.query.filter || 'alltime';   // alltime | month | local
  const beach  = req.query.beach  || null;
  const limit  = Math.min(Number(req.query.limit) || 50, 100);
  const viewer = optionalAuth(req);

  try {
    let rows;

    if (filter === 'month') {
      // Join users with monthly_points for the current calendar month
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);

      const result = await query(
        `SELECT u.id, u.name, u.initials, u.beach,
                COALESCE(mp.points, 0)     AS points,
                COALESCE(mp.shells, 0)     AS shells,
                COALESCE(mp.rare_finds, 0) AS rare_finds
           FROM users u
           LEFT JOIN monthly_points mp
             ON mp.user_id = u.id
            AND mp.month = $1
          ORDER BY points DESC, u.name ASC
          LIMIT $2`,
        [monthStart.toISOString().slice(0, 10), limit]
      );
      rows = result.rows;

    } else if (filter === 'local') {
      // Filter by beach name — defaults to viewer's beach if authed,
      // otherwise requires an explicit ?beach= param.
      let targetBeach = beach;
      if (!targetBeach && viewer) {
        const { rows: [u] } = await query('SELECT beach FROM users WHERE id = $1', [viewer.id]);
        targetBeach = u ? u.beach : null;
      }
      if (!targetBeach) {
        return res.status(400).json({ error: 'Provide ?beach= or authenticate to use the local filter.' });
      }
      const result = await query(
        `SELECT id, name, initials, beach, points, shells_found AS shells, rare_finds
           FROM users
          WHERE beach = $1
          ORDER BY points DESC, name ASC
          LIMIT $2`,
        [targetBeach, limit]
      );
      rows = result.rows;

    } else {
      // alltime — plain user totals
      const result = await query(
        `SELECT id, name, initials, beach, points, shells_found AS shells, rare_finds
           FROM users
          ORDER BY points DESC, name ASC
          LIMIT $1`,
        [limit]
      );
      rows = result.rows;
    }

    const leaderboard = rows.map((r, i) => ({
      rank:      i + 1,
      id:        r.id,
      name:      r.name,
      initials:  r.initials,
      beach:     r.beach,
      points:    Number(r.points),
      shells:    Number(r.shells),
      rareFinds: Number(r.rare_finds),
      isActive:  viewer ? r.id === viewer.id : false,
    }));

    return res.json({ filter, leaderboard });
  } catch (err) {
    console.error('[leaderboard GET]', err.message);
    return res.status(500).json({ error: 'Server error fetching leaderboard.' });
  }
});

module.exports = router;
