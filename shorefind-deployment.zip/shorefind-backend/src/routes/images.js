/**
 * src/routes/images.js
 *
 * POST /images/upload
 *   Accepts a multipart image, resizes it to max 640px with sharp,
 *   and saves it under /public/uploads/<uuid>.jpg.
 *   Returns { url } pointing to the served file.
 *
 * In production swap the local disk save for an S3/R2 upload — only
 * this file needs to change; everything else stays the same.
 */
const router  = require('express').Router();
const multer  = require('multer');
const sharp   = require('sharp');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const { requireAuth } = require('../middleware/auth');

// Store the original in memory; sharp will write the resized version.
const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 10 * 1024 * 1024 }, // 10 MB raw upload cap
  fileFilter(req, file, cb) {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files are accepted.'));
    }
    cb(null, true);
  },
});

const UPLOAD_DIR = process.env.UPLOAD_DIR
  ? path.resolve(process.env.UPLOAD_DIR)
  : path.join(__dirname, '../../public/uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

router.post('/upload', requireAuth, upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No image file received.' });
  }

  try {
    const filename = `${uuidv4()}.jpg`;
    const dest     = path.join(UPLOAD_DIR, filename);

    await sharp(req.file.buffer)
      .resize(640, 640, { fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: 78 })
      .toFile(dest);

    // Public URL: works when Express serves /public as a static dir.
    // In production replace with: `https://cdn.yourdomain.com/uploads/${filename}`
    const url = `${process.env.FRONTEND_URL || ''}/uploads/${filename}`;
    return res.json({ url });
  } catch (err) {
    console.error('[images/upload]', err.message);
    return res.status(500).json({ error: 'Image processing failed.' });
  }
});

// Handle multer errors (file too large, wrong type)
router.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'Image must be under 10 MB.' });
  }
  return res.status(400).json({ error: err.message });
});

module.exports = router;
