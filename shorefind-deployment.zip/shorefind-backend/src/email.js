/**
 * src/email.js
 * Transactional email via Resend (https://resend.com).
 * Free tier: 3 000 emails / month, 100 / day.
 *
 * To swap providers later, replace only the `send()` function body —
 * all callers use sendWelcomeEmail(user) and are provider-agnostic.
 */
const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM   = process.env.EMAIL_FROM || 'ShoreFind <hello@shorefind.app>';

/**
 * Low-level send wrapper. Returns { id } on success, throws on failure.
 */
async function send({ to, subject, html, text }) {
  if (!process.env.RESEND_API_KEY || process.env.RESEND_API_KEY === 're_xxxxxxxxxxxxxxxxxxxx') {
    // No key configured — log the email to the console instead of erroring.
    console.log(`\n[email] Would send to ${to}\nSubject: ${subject}\n---\n${text}\n---\n`);
    return { id: 'dev-console' };
  }
  const { data, error } = await resend.emails.send({ from: FROM, to, subject, html, text });
  if (error) throw new Error(`Resend error: ${JSON.stringify(error)}`);
  return data;
}

// ── Email templates ───────────────────────────────────────────

function welcomeHtml(user) {
  const firstName = user.name.split(' ')[0];
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Welcome to ShoreFind</title>
<style>
  body{margin:0;padding:0;background:#F3ECDA;font-family:'Helvetica Neue',Arial,sans-serif;color:#16262E;}
  .wrap{max-width:560px;margin:32px auto;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(22,38,46,.12);}
  .header{background:#1B3A4B;padding:40px 32px 32px;text-align:center;}
  .logo{font-size:22px;font-weight:700;color:#fff;letter-spacing:-.5px;margin-bottom:2px;}
  .sub{font-size:11px;text-transform:uppercase;letter-spacing:2px;color:#A8DAD6;}
  .avatar{width:44px;height:44px;border-radius:50%;background:#E8865A;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px;margin:-22px auto 16px;position:relative;top:12px;}
  .body{background:#fff;padding:40px 32px 32px;}
  h1{font-size:26px;font-weight:700;margin:0 0 6px;text-align:center;}
  .tagline{color:#1B3A4B99;font-size:14px;text-align:center;margin:0 0 28px;}
  p{font-size:14px;line-height:1.65;color:#16262Ecc;margin:0 0 16px;}
  .feature{display:flex;gap:14px;margin-bottom:18px;align-items:flex-start;}
  .icon{width:38px;height:38px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:18px;}
  .feature-body h3{margin:0 0 2px;font-size:14px;color:#16262E;}
  .feature-body p{margin:0;font-size:13px;color:#16262E99;}
  .cta{text-align:center;margin:28px 0;}
  .btn{display:inline-block;background:#1B3A4B;color:#fff;text-decoration:none;padding:12px 32px;border-radius:100px;font-size:14px;font-weight:600;}
  .points-box{background:#F3ECDA;border-radius:12px;padding:18px 20px;margin:0 0 28px;}
  .points-box h4{margin:0 0 12px;font-size:13px;color:#16262E;}
  .points-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
  .rarity{display:flex;align-items:center;gap:6px;font-size:12px;color:#16262Ecc;}
  .dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
  .footer{background:#F3ECDA;padding:20px 32px;text-align:center;}
  .footer p{font-size:11px;color:#16262E66;margin:2px 0;}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="logo">🐚 ShoreFind</div>
    <div class="sub">Field Log · Beachcombers Community</div>
  </div>
  <div style="text-align:center;background:#fff;padding-top:0;">
    <div class="avatar">${user.initials}</div>
  </div>
  <div class="body">
    <h1>Welcome, ${firstName}!</h1>
    <p class="tagline">Your beachcombing journey starts here.</p>
    <p>You're officially part of the ShoreFind community — a growing group of beachcombers who document, identify, and celebrate every shell the tide brings in.</p>
    <div class="feature">
      <div class="icon" style="background:#6FBEB820;">📷</div>
      <div class="feature-body">
        <h3>Scan any shell</h3>
        <p>Upload a photo or snap one on the sand. ShoreFind matches it against a field guide of species and gives you a confidence score and key facts.</p>
      </div>
    </div>
    <div class="feature">
      <div class="icon" style="background:#E8865A20;">⭐</div>
      <div class="feature-body">
        <h3>Earn points by rarity</h3>
        <p>Common shells earn 10 pts. Rare finds earn 50. Land an Ultra-Rare and pocket 100. Every shell logged adds to your permanent record.</p>
      </div>
    </div>
    <div class="feature">
      <div class="icon" style="background:#B8901F20;">🏆</div>
      <div class="feature-body">
        <h3>Climb the leaderboard</h3>
        <p>Rank against fellow beachcombers — all-time, this month, or just your local beach. Your row updates the moment you log a find.</p>
      </div>
    </div>
    <div class="points-box">
      <h4>Rarity point guide</h4>
      <div class="points-grid">
        <div class="rarity"><div class="dot" style="background:#6E8B6E;"></div>Common — 10 pts</div>
        <div class="rarity"><div class="dot" style="background:#3E7C8C;"></div>Uncommon — 25 pts</div>
        <div class="rarity"><div class="dot" style="background:#B3733F;"></div>Rare — 50 pts</div>
        <div class="rarity"><div class="dot" style="background:#B8901F;"></div>Ultra-Rare — 100 pts</div>
      </div>
    </div>
    <div class="cta">
      <a href="${process.env.FRONTEND_URL || 'https://shorefind.app'}" class="btn">Open ShoreFind →</a>
    </div>
  </div>
  <div class="footer">
    <p>You're receiving this because you signed up for ShoreFind.</p>
    <p>© ${new Date().getFullYear()} ShoreFind. Built for beachcombers.</p>
  </div>
</div>
</body>
</html>`;
}

function welcomeText(user) {
  const firstName = user.name.split(' ')[0];
  return `Hey ${firstName},

Welcome to ShoreFind! You're now part of a community of beachcombers who document, identify, and celebrate every shell the tide brings in.

WHAT YOU CAN DO:

📷 Scan any shell
Upload a photo or snap one on the sand. ShoreFind identifies it, gives you a confidence score, and shows you key facts.

⭐ Earn points by rarity
Common: 10 pts · Uncommon: 25 pts · Rare: 50 pts · Ultra-Rare: 100 pts

🏆 Climb the leaderboard
Rank against fellow beachcombers — all-time, this month, or your local beach.

Open ShoreFind: ${process.env.FRONTEND_URL || 'https://shorefind.app'}

Happy hunting,
The ShoreFind Team

—
© ${new Date().getFullYear()} ShoreFind. Built for beachcombers.
You're receiving this because you signed up for ShoreFind.`;
}

// ── Public API ────────────────────────────────────────────────

/**
 * Send the welcome email to a newly registered user.
 * Errors are caught and logged — a failed welcome email should
 * never block the signup response.
 */
async function sendWelcomeEmail(user) {
  try {
    const result = await send({
      to:      user.email,
      subject: `Welcome to ShoreFind — your tide's in 🐚`,
      html:    welcomeHtml(user),
      text:    welcomeText(user),
    });
    console.log(`[email] welcome sent to ${user.email} (id: ${result.id})`);
  } catch (err) {
    // Non-fatal: log and continue — user is already signed up.
    console.error(`[email] failed to send welcome to ${user.email}:`, err.message);
  }
}

module.exports = { sendWelcomeEmail };
