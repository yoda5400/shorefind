/**
 * src/db.js
 * Shared PostgreSQL connection pool.
 * All modules import { pool, query } from here.
 */
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // In production use SSL. Render, Supabase, and Railway all require it.
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
});

pool.on('error', (err) => {
  console.error('[db] unexpected pool error', err.message);
});

/**
 * Convenience wrapper for one-off queries.
 * @param {string} text  - Parameterised SQL
 * @param {any[]}  params
 * @returns {Promise<import('pg').QueryResult>}
 */
async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  if (process.env.NODE_ENV !== 'production') {
    const ms = Date.now() - start;
    if (ms > 200) console.warn(`[db] slow query (${ms}ms): ${text.slice(0, 80)}`);
  }
  return res;
}

module.exports = { pool, query };
