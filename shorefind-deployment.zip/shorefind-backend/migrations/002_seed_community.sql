-- 002_seed_community.sql
-- Inserts seed beachcombers so the leaderboard is never empty on first deploy.
-- All seed accounts share the same hashed password "shorefind2025" (bcrypt).
-- These are display-only accounts — users cannot log in as them.

INSERT INTO users (email, name, initials, beach, password_hash, points, shells_found, rare_finds)
VALUES
  ('dana@seed.shorefind.app',   'Dana Okafor',    'DO', 'Driftwood Cove',        '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 1840, 61, 9),
  ('theo@seed.shorefind.app',   'Theo Marchetti', 'TM', 'Driftwood Cove',        '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 1615, 54, 7),
  ('priya@seed.shorefind.app',  'Priya Anand',    'PA', 'Driftwood Cove',        '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 1330, 47, 6),
  ('wes@seed.shorefind.app',    'Wes Callahan',   'WC', 'Cape Elara Shoreline',  '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 980,  39, 4),
  ('lucia@seed.shorefind.app',  'Lucia Fontes',   'LF', 'Cape Elara Shoreline',  '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 745,  31, 3),
  ('sam@seed.shorefind.app',    'Sam Okoye',      'SO', 'Cape Elara Shoreline',  '$2b$10$zGQ2nYtVrx7JdC.u5Hn7CeGp9XhFnZKmLp.8Q4A5wXg1V2RbTYIqS', 520,  24, 2)
ON CONFLICT (email) DO NOTHING;

-- Seed some monthly points for the current month so "This Month" isn't empty
INSERT INTO monthly_points (user_id, month, points, shells, rare_finds)
SELECT id,
       DATE_TRUNC('month', NOW())::DATE,
       CASE email
         WHEN 'dana@seed.shorefind.app'  THEN 385
         WHEN 'theo@seed.shorefind.app'  THEN 235
         WHEN 'priya@seed.shorefind.app' THEN 410
         WHEN 'wes@seed.shorefind.app'   THEN 150
         WHEN 'lucia@seed.shorefind.app' THEN 260
         WHEN 'sam@seed.shorefind.app'   THEN 95
       END,
       CASE email
         WHEN 'dana@seed.shorefind.app'  THEN 12
         WHEN 'theo@seed.shorefind.app'  THEN 9
         WHEN 'priya@seed.shorefind.app' THEN 14
         WHEN 'wes@seed.shorefind.app'   THEN 6
         WHEN 'lucia@seed.shorefind.app' THEN 10
         WHEN 'sam@seed.shorefind.app'   THEN 4
       END,
       CASE email
         WHEN 'dana@seed.shorefind.app'  THEN 3
         WHEN 'theo@seed.shorefind.app'  THEN 1
         WHEN 'priya@seed.shorefind.app' THEN 2
         WHEN 'wes@seed.shorefind.app'   THEN 0
         WHEN 'lucia@seed.shorefind.app' THEN 1
         WHEN 'sam@seed.shorefind.app'   THEN 0
       END
FROM users
WHERE email LIKE '%@seed.shorefind.app'
ON CONFLICT DO NOTHING;
