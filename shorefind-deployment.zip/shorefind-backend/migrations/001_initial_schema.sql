-- 001_initial_schema.sql
-- Creates the core ShoreFind schema.

-- Extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT        NOT NULL UNIQUE,
  name          TEXT        NOT NULL,
  initials      TEXT        NOT NULL,
  beach         TEXT        NOT NULL DEFAULT 'Cape Elara Shoreline',
  password_hash TEXT        NOT NULL,
  points        INTEGER     NOT NULL DEFAULT 0,
  shells_found  INTEGER     NOT NULL DEFAULT 0,
  rare_finds    INTEGER     NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);

-- ── Logbook entries ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS logbook_entries (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  shell_id      TEXT        NOT NULL,
  shell_name    TEXT        NOT NULL,
  sci_name      TEXT        NOT NULL,
  rarity        TEXT        NOT NULL CHECK (rarity IN ('common','uncommon','rare','ultra')),
  points        INTEGER     NOT NULL,
  confidence    INTEGER     NOT NULL CHECK (confidence BETWEEN 0 AND 100),
  image_url     TEXT,                  -- NULL means image was not stored server-side
  fact          TEXT,
  found_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logbook_user ON logbook_entries (user_id, found_at DESC);

-- ── Monthly points ledger ─────────────────────────────────────
-- One row per user per calendar month, kept in sync on every scan log.
-- Makes "This Month" leaderboard queries a simple indexed lookup.
CREATE TABLE IF NOT EXISTS monthly_points (
  user_id       UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  month         DATE        NOT NULL,  -- always first day of the month, e.g. 2025-07-01
  points        INTEGER     NOT NULL DEFAULT 0,
  shells        INTEGER     NOT NULL DEFAULT 0,
  rare_finds    INTEGER     NOT NULL DEFAULT 0,
  PRIMARY KEY   (user_id, month)
);

-- ── updated_at auto-stamp ─────────────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_users_updated_at ON users;
CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
