/**
 * migrations/run.js
 * Run all SQL migration files in lexicographic order.
 * Safe to run multiple times — tracks completed migrations in a
 * migrations_log table so each file is applied only once.
 *
 * Usage:  node migrations/run.js
 */
require('dotenv').config();
const fs   = require('fs');
const path = require('path');
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function run() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS migrations_log (
        id         SERIAL PRIMARY KEY,
        filename   TEXT NOT NULL UNIQUE,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    const files = fs.readdirSync(__dirname)
      .filter(f => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      const { rows } = await client.query(
        'SELECT 1 FROM migrations_log WHERE filename = $1', [file]
      );
      if (rows.length) {
        console.log(`  skip  ${file} (already applied)`);
        continue;
      }
      const sql = fs.readFileSync(path.join(__dirname, file), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO migrations_log (filename) VALUES ($1)', [file]);
        await client.query('COMMIT');
        console.log(`  ✔     ${file}`);
      } catch (err) {
        await client.query('ROLLBACK');
        console.error(`  ✖     ${file}`, err.message);
        process.exit(1);
      }
    }
    console.log('Migrations done.');
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch(err => { console.error(err); process.exit(1); });
